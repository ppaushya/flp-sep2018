package org.capgemini;

public class Salary extends Employee{

}
