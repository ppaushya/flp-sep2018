package org.cap.nio.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;

public class NIODemo {

	public static void main(String[] args) {
		
		File src=new File("C:\\demo\\filedemo\\ObjectWriteDemo.java");
		
		File des=new File("C:\\demo\\filedemo\\destination.txt");
		
		
		FileInputStream in=null;
		FileOutputStream out=null;
		
		try {
			in = new FileInputStream(src);
			ReadableByteChannel reader=in.getChannel();
			
			out=new FileOutputStream(des);
			WritableByteChannel writer=out.getChannel();
			
			
			ByteBuffer buffer=ByteBuffer.allocate(10*1024);
			while(reader.read(buffer)!=-1) {
				
				buffer.flip();
				while(buffer.hasRemaining()) {
					writer.write(buffer);
				}
				buffer.clear();
				
			}
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				in.close();
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		
		
		
		

	}

}
