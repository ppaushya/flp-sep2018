package org.cap.nio.demo;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Pathdemo {

	public static void main(String[] args) {
		Path path=Paths.get("C:\\vidavid\\FLP\\FLP_2018\\java full stack 10 weeks  core java\\ClassBook-Les17-CoreJava8 - File IO.pdf");
		
		

	}

}
