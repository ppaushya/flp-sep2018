package org.cap.object.demo;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DemoRead {

	public static void main(String[] args) {
		File file=new File("C:\\demo\\filedemo\\product.dat");
		FileInputStream in;
		ObjectInputStream objIn;
		
		try{
			in=new FileInputStream(file);
			objIn=new ObjectInputStream(in);
			Product product1;
			product1=(Product)objIn.readObject();
			
			while(objIn.readObject()!=null){
				System.out.println(product1);
				product1=(Product)objIn.readObject();
			
			}
			
		} catch (EOFException e) {
			// TODO: handle exception
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		}


	}

