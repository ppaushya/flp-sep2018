package org.cap.object.demo;

import java.time.LocalDate;
import java.util.Scanner;

public class UserInteraction {
	
	Scanner scanner=new Scanner(System.in);
	
	public Product getProduct() {
		Product product=new Product();
		
		System.out.println("Enter ProductId:");
		product.setProductId(scanner.nextInt());
		
		System.out.println("Enter Product name:");
		product.setProductName(scanner.next());
		
		System.out.println("Enter Quantity:");
		product.setQuantity(scanner.nextInt());
		
		System.out.println("Enter Price:");
		product.setPrice(scanner.nextDouble());
		
		product.setExpiryDate(LocalDate.now());
		
		return product;
	}

}
