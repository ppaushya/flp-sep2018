package org.cap.object.demo;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.Scanner;



public class ObjectWriteDemo {
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
	File file=new File("C:\\demo\\filedemo\\product.dat");
	
	UserInteraction ui=new UserInteraction();
	
	try(FileOutputStream stream=new FileOutputStream(file,true);
			ObjectOutputStream outputStream=new ObjectOutputStream(stream)){
		
		String choice; 
		do {
		Product product=ui.getProduct();
		//Product product=new Product(101, "Samsung Mobile", 10, 34000, LocalDate.of(2030, 3, 12));
		outputStream.writeObject(product);
		System.out.println("You wish to continue?[y|n]");
		choice=scanner.next();
		}while(choice.charAt(0)=='y');
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	FileInputStream in;
	ObjectInputStream objIn;
	
	try{
		in=new FileInputStream(file);
		objIn=new ObjectInputStream(in);
		Product product1;
		product1=(Product)objIn.readObject();
		
		while(product1!=null){
			System.out.println(product1);
			product1=(Product)objIn.readObject();
		
		}
		
	} catch (EOFException e) {
		// TODO: handle exception
	}catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	}
	
	}
	

