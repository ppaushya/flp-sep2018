package org.cap.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		
		File file=new File("C:\\vidavid1");
		
		file.delete();
		
		/*if(file.isFile()) {
			if(file.exists()) {
				System.out.println("Readable:" + file.canRead());
				System.out.println("Writable:" + file.canWrite());
				System.out.println("Executable:" + file.canExecute());
				System.out.println("path:" + file.getAbsolutePath());
			}else {
				System.out.println("Sorry! File does not exists!");
			}
		}else if(file.isDirectory()) {
			String[] names=file.list();
			for(String name:names)
				System.out.println(name);
			
		}else {
			System.out.println("Sorry! No file/Directory exists!");
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		*/
		System.out.println("FreeSpace:" + file.getFreeSpace());
		System.out.println("TotalSpace:" + file.getTotalSpace());
		System.out.println("UsedSpace:" + file.getUsableSpace());
		
	}

}
