package org.cap.demo;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DemoBufferedReader {

	public static void main(String[] args) {
		
		File file=new File("C:\\demo\\filedemo\\mydemo.txt");
		
		
		try(FileInputStream in=new FileInputStream(file);
				BufferedInputStream inputStream=new BufferedInputStream(in)) {
			
			/*int mybyte=inputStream.read();
			while(mybyte!=-1) {
			System.out.print((char)mybyte);
			mybyte=inputStream.read();
			}*/
			
			byte[] arr=new byte[100];
			inputStream.read(arr);
			for(byte ch:arr)
				System.out.print((char)ch);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
	}

}
