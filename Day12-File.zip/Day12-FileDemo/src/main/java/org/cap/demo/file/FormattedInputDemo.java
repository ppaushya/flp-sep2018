package org.cap.demo.file;

public class FormattedInputDemo {

	public static void main(String[] args) {
		

	}

}
