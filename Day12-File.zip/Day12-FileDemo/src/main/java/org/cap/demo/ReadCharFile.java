package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

public class ReadCharFile {

	public static void main(String[] args) {
		File file=new File("C:\\demo\\filedemo\\mydemo.txt");
		int ch;
		try(FileReader reader=new FileReader(file)) {
			ch=reader.read();
			while(ch!=-1) {
				System.out.print((char)ch);
			ch=reader.read();
		
			
		}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
