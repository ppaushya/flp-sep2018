package org.cap.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharDemo {

	public static void main(String[] args) {
		File file=new File("C:\\demo\\filedemo\\sample1.txt");
		
		
		String greetings="Do not sleep in my class!";
		//int ch;
		try(FileWriter writer=new FileWriter(file)) {
			/*char[] ch=greetings.toCharArray();
			
			for(char c:ch)
				writer.write(c);*/
			
			writer.write(greetings);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
