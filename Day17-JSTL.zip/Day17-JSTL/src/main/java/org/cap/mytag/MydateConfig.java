package org.cap.mytag;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MydateConfig extends SimpleTagSupport{
	
	private String printDate;
	private String dateFormat;
	
	

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}



	public void setPrintDate(String printDate) {
		this.printDate = printDate;
	}



	@Override
	public void doTag() throws JspException, IOException {
		String finalDate=null;
		Date date=null;
		SimpleDateFormat dateFormat=null;
		if(printDate!=null)
			date=new Date(this.printDate);
		else
			date=new Date();
		
		JspWriter out= getJspContext().getOut();
		if(this.dateFormat!=null)
		{
			dateFormat=new SimpleDateFormat(this.dateFormat);
		}
		
			
	
			out.println("<h4>My Date: <span style='color:red;'>" +dateFormat.format(date)  +"</span></h4>");
		
	}

	
	
}
