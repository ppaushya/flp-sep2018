package org.cap.dao;

public class MainClass {

	public static void main(String[] args) {
		
		TransactionDao dao=new TransactionDaoImpl();
		dao.performTransaction();
		
	}

}
