package org.cap.dao;

public interface TransactionDao {

	public void performTransaction();
}
