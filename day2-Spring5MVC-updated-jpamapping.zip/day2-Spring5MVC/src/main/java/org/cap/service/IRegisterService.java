package org.cap.service;

import java.util.List;

import org.cap.model.Register;

public interface IRegisterService {
	
	public void insertRegistration(Register register);
	public List<Register> getAllRegistration();
	public void deleteRegistration(int registrationId) ;
	public Register findRegistration(int registrationId);
	public void updateRegistration(Register register);
}
