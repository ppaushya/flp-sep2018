package org.cap.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Register {
	
	@Id
	@GeneratedValue
	private int registrationId;
	@NotEmpty(message="* Please enter FirstName")
	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String gender;
	private String qualification;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="dd-MMM-yyyy")
	@Past(message="* Please enter past date")
	private Date dateOfBirth;
	
	@Email(message="*Please provide valid Email Id")
	@NotEmpty(message="*Please enter email id.")
	private String email;
	
	@Length(min=6,max=16,message="* Password must be between 6 to 16 chars")
	private String password;
	
	@Transient
	private String confirmpassword;
	@Range(min=2000,max=50000,message="* Registration Fees should be between 2000 and 50000")
	private double regFees;
	
	
	@OneToOne
	@JoinColumn(name="customerId")
	private Customer customer;
	
	
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Register() {
		
	}
	
	public Register(String firstName, String lastName, String address, String city, String gender, String qualification,
			Date dateOfBirth, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
	}
	
	
	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	public int getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getRegFees() {
		return regFees;
	}

	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	@Override
	public String toString() {
		return "Register [registrationId=" + registrationId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + ", city=" + city + ", gender=" + gender + ", qualification=" + qualification
				+ ", dateOfBirth=" + dateOfBirth + ", email=" + email + ", password=" + password + ", confirmpassword="
				+ confirmpassword + ", regFees=" + regFees + "]";
	}

	
	

}
