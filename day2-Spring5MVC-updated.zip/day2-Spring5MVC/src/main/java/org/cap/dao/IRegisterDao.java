package org.cap.dao;

import java.util.List;

import org.cap.model.Register;

public interface IRegisterDao {
	public void insertRegistration(Register register);
	public List<Register> getAllRegistration();
	
	public void deleteRegistration(int registrationId);
	
	public Register findRegistration(int registrationId);
}
