package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.cap.inherit.model.Module;
import org.cap.inherit.model.Project;
import org.cap.inherit.model.Task;

public class TestInheritance {

	public static void main(String[] args) {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
			Project project=new Project(1001, "CapgBanking");
			
			Module module=new Module();
			module.setProjectId(1002);
			module.setProjectName("Wallet App");
			module.setModuleName("Login Module");
			
			Task task=new Task();
			task.setProjectId(1003);
			task.setProjectName("Citi Bank");
			task.setModuleName("Validate Forms");
			task.setTaskName("JavaScript Validation");
			
			
			entityManager.persist(project);
			entityManager.persist(module);
			entityManager.persist(task);
			
		
		transaction.commit();
	}

}
