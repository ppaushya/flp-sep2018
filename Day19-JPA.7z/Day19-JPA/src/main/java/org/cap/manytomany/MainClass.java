package org.cap.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		Event event=new Event();
		event.setEventId(101);
		event.setEventName("Java");
		
		
		Event event1=new Event();
		event1.setEventId(102);
		event1.setEventName("Oracle");
		
		Delegate delegate=new Delegate();
		delegate.setDelegateId(1);
		delegate.setDelegateName("tom");
		

		Delegate delegate1=new Delegate();
		delegate1.setDelegateId(2);
		delegate1.setDelegateName("Sam");
		

		Delegate delegate2=new Delegate();
		delegate2.setDelegateId(3);
		delegate2.setDelegateName("Ram");
		
		
		delegate.getEvents().add(event);
		delegate.getEvents().add(event1);
		delegate1.getEvents().add(event1);
		delegate2.getEvents().add(event);
		delegate2.getEvents().add(event1);
		
		
		entityManager.persist(event);
		entityManager.persist(event1);
		entityManager.persist(delegate);
		entityManager.persist(delegate1);
		entityManager.persist(delegate2);
		
		
		
		transaction.commit();
	}

}
