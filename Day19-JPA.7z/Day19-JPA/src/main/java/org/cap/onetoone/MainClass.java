package org.cap.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		Address address=new Address(1, "19/A, North avvennue");
		Customer customer=new Customer(1001, "Tom");
		address.setCustomer(customer);
		
		//entityManager.persist(customer);
		entityManager.persist(address);
		
		transaction.commit();
	}

}
