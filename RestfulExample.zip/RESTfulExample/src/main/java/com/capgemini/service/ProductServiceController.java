package com.capgemini.service;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.capgemini.dao.IProductDao;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.model.Product;

@Path("/api")
public class ProductServiceController {
	
	private IProductDao prodDao=new ProductDaoImpl();
	
	@Path("/addproduct")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> addProduct(@FormParam("productId")int productId,
			@FormParam("productName") String productName) {
		Product product=new Product(productId, productName);
		List<Product> list= prodDao.getAllProducts();
		list.add(product);
		return list;
		
		
	}

	@GET
	@Path("/products")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getAllProducts(){
		//return Response.status(200).entity(prodDao.getAllProducts()).build();
		//System.out.println(prodDao.getAllProducts());
		return prodDao.getAllProducts();
	}
	
}
