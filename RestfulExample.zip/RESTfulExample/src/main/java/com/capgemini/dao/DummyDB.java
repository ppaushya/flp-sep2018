package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.model.Product;

public class DummyDB {
	private static List<Product> products=getDbList();
	
	public static List<Product> getDbList(){
		
		List<Product> products=new ArrayList();
		products.add(new Product(1, "Samsung J5"));
		products.add(new Product(2, "Sony Xperia"));
		products.add(new Product(3, "Apple Xs"));
		products.add(new Product(8, "Samsung J7"));
		return products;
		
	}
}
