package org.cap.interthread;

public class Product {
	
	int quantity;
	
	
	
	
	public Product(int quantity) {
		super();
		this.quantity = quantity;
	}


	public synchronized void consume(int qty) {
	
		System.out.println("Consuming product...................");
		System.out.println("Current qty:" + this.quantity);
		//do{
		if(this.quantity<qty) {
			try {
				System.out.println("Insufficient Qty! I am waiting.................");
				wait(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	//	}while(this.quantity<qty);
			System.out.println("Operation resumed.....");
		
			this.quantity-=qty;
			System.out.println("Updated Qty after consume:"+this.quantity);
		
			
	}
	
	
	public synchronized void produce(int qty) {
	
		System.out.println("Producing product...................");
		System.out.println("Current qty:" + this.quantity);
		this.quantity+=qty;
		System.out.println("I am notifying the threads...................");
		System.out.println("Updated Qty after produce:"+this.quantity);
		notifyAll();
		
	}
	
	
	

}
