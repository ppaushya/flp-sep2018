package org.cap.interthread;

public class DeadLockDemo {

	public static void main(String[] args) {
		
		
		String resource1="Capgemini";
		String resource2="Capg FLP Team";
		
		
		
		Thread t1=new Thread() {
			@Override
			public void run() {
				
				synchronized (resource1) {
					
					System.out.println(Thread.currentThread().getName() + " -->Thread Lock: Resource1");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					synchronized (resource2) {
						System.out.println(Thread.currentThread().getName() + " -->Thread Lock: Resource2");
					}
				}
				
			}
		};
		
		
		
		
		
		
		

		Thread t2=new Thread() {
			@Override
			public void run() {
				
				synchronized (resource2) {
					
					System.out.println(Thread.currentThread().getName() + " -->Thread Lock: Resource2");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					synchronized (resource1) {
						System.out.println(Thread.currentThread().getName() + " -->Thread Lock: Resource1");
					}
				}
				
			}
		};
		
		t1.setPriority(Thread.MAX_PRIORITY);
		System.out.println(t1.getPriority());
		
		t1.start();
		t2.start();

	}

}
