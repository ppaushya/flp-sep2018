package org.cap.interthread;

public class MainClass {

	public static void main(String[] args) {
		final Product product=new Product(50);
		
		
		Thread consumer=new Thread() {
			@Override
			public void run() {
				product.consume(80);
			}
		};

		consumer.start();
		
		
		Thread consumer1=new Thread() {
			@Override
			public void run() {
				product.consume(60);
			}
		};

		consumer1.start();

		Thread producer=new Thread() {
			@Override
			public void run() {
				product.produce(40);
			}
		};

		producer.start();
		
	}

}
