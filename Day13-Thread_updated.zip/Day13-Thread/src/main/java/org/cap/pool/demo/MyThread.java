package org.cap.pool.demo;

public class MyThread implements Runnable{

	@Override
	public void run() {
		System.out.println("--> " + Thread.currentThread().getName() + " I am started...");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("---> " + Thread.currentThread().getName() + " I am Ending...");
		
		
	}

	@Override
	protected void finalize() throws Throwable {
		System.out.println("Object collected..........");
	}
	
	
	

}
