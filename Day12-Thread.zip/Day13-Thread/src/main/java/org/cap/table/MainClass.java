package org.cap.table;

public class MainClass {

	public static void main(String[] args) {
		 final TableThread table=new TableThread();
		
		Thread  t1=new Thread() {
			@Override
			public void run() {
				//table.setNum(13);
				table.printTable(13);
				//table.info();
			}
		};
		
		Thread  t2=new Thread() {
			@Override
			public void run() {
			//	table.setNum(15);
				table.printTable(15);
				//table.info();
			}
		};
		
		
		Thread  t3=new Thread() {
			@Override
			public void run() {
				//table.setNum(21);
				table.printTable(21);
				
			}
		};
		t1.start();
		t2.start();
		t3.start();

	}

}
