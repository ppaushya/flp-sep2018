package org.cap.table;

public class TestClass {

	public static void main(String[] args) {
		
		TableThread tableThread=new TableThread();
		
		Runnable runnable=new Runnable() {
			
			@Override
			public void run() {
				//tableThread.setNum(13);
				tableThread.printTable(13);
				
			}
		};
		
		Thread t1=new Thread(runnable);
		t1.start();
		
		
		Runnable runnable1=new Runnable() {
			
			@Override
			public void run() {
				//tableThread.setNum(15);
				tableThread.printTable(15);
				
			}
		};
		
		Thread t2=new Thread(runnable1);
		t2.start();
		
		
		Runnable runnable2=new Runnable() {
			
			@Override
			public void run() {
				for(int i=0;i<1000;i++)
					System.out.println(Thread.currentThread().getName() + "-->" +i);
			}
		};
		
		Thread t3=new Thread(runnable2);
		t3.setDaemon(true);
		t3.start();
		
		System.out.println("Program terminated......");
	}
	
	
	

}
