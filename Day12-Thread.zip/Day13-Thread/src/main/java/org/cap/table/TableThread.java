package org.cap.table;

public class TableThread {
	
	
	
	public TableThread() {
		
	}
	
	
	
	
	
	

	 public  void printTable(int num) {
		 System.out.println(Thread.currentThread().getName() +"-->"+ "Print Table started");
		
		 synchronized (this)
		 {
			 for(int i=1;i<=20;i++)
		
			System.out.println(Thread.currentThread().getName() +"-->"+ 
						i+"*"+num+"="+(i*num));
		 }
		
		System.out.println(Thread.currentThread().getName() +"-->"+ "Print Table Ended");
	}
	 
	/* 
	 public void info() {
		 for(int i=0;i<10;i++)
			 System.out.println(Thread.currentThread().getName() +"Thread Demo...");
		 System.out.println(Thread.currentThread().getName() + "Not synchronized method .....Thread ...");
	 }
	
	
*/
}
