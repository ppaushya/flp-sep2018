package org.cap.table;

public class TestClass1 {

	public static void main(String[] args) {
		
		final StaticSync obj=new StaticSync();
	
		Thread t1=new Thread() {
			@Override
			public void run() {
				StaticSync.staticMethod();
			}
		};
		
		

		
		t1.start();
		
		Thread t2=new Thread() {
			@Override
			public void run() {
				StaticSync.staticMethod();
			}
		};

		
		t2.start();
		
		
		Thread t3=new Thread() {
			@Override
			public void run() {
				obj.show();
			}
		};
		t3.start();
		
	}

}
