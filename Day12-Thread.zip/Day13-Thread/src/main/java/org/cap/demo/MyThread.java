package org.cap.demo;

public class MyThread extends Thread{
	
	
	public MyThread() {
		
	}
	public MyThread(String threadName) {
		super(threadName);
	}
	
	
	@Override
	public void run() {
		System.out.println( getName() + " --> Thread started......");
	}

}
