package org.capg.demo;

public class MainClass {

	public static void main(String[] args) {
		
		ThreadDemo runnable=new ThreadDemo();
		Thread t1=new Thread(runnable);
		Thread t2=new Thread(runnable,"capgThread");
		Thread t3=new Thread(runnable);
		t2.start();
		t1.start();
		
		
	try {
		t1.join(100);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	
	
	try {
		t2.join();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	t3.start();
		
		
		
	}

}
