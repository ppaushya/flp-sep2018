package org.cap.account.model;

public class Account {
	
	private int accountNo;
	private String accountType;
	private double balance;
	
	public Account() {
		
	}
	
	public Account(int accountNo, String accountType, double balance) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.balance = balance;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", balance=" + balance + "]";
	}
	
	

}
