package org.cap.account.dao;

import org.cap.account.model.Customer;

public interface IAccountDao {

	public boolean addAccount(Customer customer);
}
