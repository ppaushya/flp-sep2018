package org.cap.sample;

public class Demo {

	public static void main(String[] args) {
		Integer integer=new Integer(23);
		int num=100;
		
		//Primitive to Object (Autoboxing)
		integer=num;
		
		System.out.println(integer);
		
		
		
		String str="123";
		Integer myNum=Integer.parseInt(str);
		
		System.out.println(myNum);
		
	//	double value=myNum.doubleValue();
		Double value=myNum.doubleValue();
		
		System.out.println(value);
		
		/*
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		
		System.out.println(Short.MAX_VALUE);
		System.out.println(Short.MIN_VALUE);
		*/
		//System.out.println(Double.MAX_NORMAL);
		/*System.out.println(Double.MIN_NORMAL);
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);
		System.out.println(Double.MAX_EXPONENT);
		System.out.println(Double.MIN_EXPONENT);*/

	}

}
