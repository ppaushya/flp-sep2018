package org.cap.sample;

public class RegularClassDemo {
	
	class InnerClass{
		String address="North Street";
		
		/*
			class Level2InnerClass{
				
			}*/
		
		public void show() {
			System.out.println(num);
			System.out.println(name);
			System.out.println(address);
		}
	}
	
	int num=100;
	String name="Tom";
	
	
	public void print() {
		
		InnerClass obj=new InnerClass();
		System.out.println(obj.address);
	}
	

	

}
