package org.cap.sample;

import org.cap.sample.RegularClassDemo.InnerClass;

public class MainClass {

	public static void main(String[] args) {
		
		/*RegularClassDemo.InnerClass obj
			=new RegularClassDemo().new InnerClass();*/
		
		
		RegularClassDemo outer=new RegularClassDemo();
		RegularClassDemo.InnerClass inner=outer.new InnerClass();
		
		//obj.show();
		
		inner.show();
		outer.print();

	}

}
