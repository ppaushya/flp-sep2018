package org.cap.demo;

public class Demo3 {

	public static void main(String[] args) {
		
		//StringBuilder buffer=new StringBuilder("Tom");
		StringBuilder buffer=new StringBuilder();
		buffer.append("Jerry");
		//StringBuffer buffer=new StringBuffer("Tom");
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
		
		
		buffer.ensureCapacity(200);
		
		//buffer.insert(0, "Jerry");
		buffer.replace(0, 3, "Jerry");
		//buffer.append("Jerry Jdhfksjhf kdshfh kfjhdkfhkjdhlkfhajkhfkhakjhf kdjs");
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());

	}

}
