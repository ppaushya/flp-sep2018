package org.cap.demo;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;



public class Demo {

	public static void main(String[] args) {
		
		LocalTime now=LocalTime.now();
		System.out.println(now);
		
		LocalTime time=LocalTime.of(23, 10);
		System.out.println(time);
		
		
		LocalTime zoneTime= LocalTime.ofInstant(Instant.now(), ZoneId.of("Pacific/Majuro"));
		
		java.util.Set<String> zones=ZoneId.getAvailableZoneIds();
		for(String zone:zones)
			System.out.println(zone);
		
		System.out.println("ZoneTime:"+ zoneTime);
		
		/*LocalDate now=LocalDate.now();
		
		LocalDate nextSunday=now.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
		
		//TemporalAdjusters.
		LocalDate previousSunday=now.with(TemporalAdjusters.previous(DayOfWeek.SATURDAY));
		
		System.out.println(nextSunday);
		System.out.println(previousSunday);*/
	}

}
