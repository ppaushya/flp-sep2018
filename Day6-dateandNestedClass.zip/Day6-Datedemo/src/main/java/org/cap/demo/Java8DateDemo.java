package org.cap.demo;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.temporal.ChronoField;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalField;
import java.time.temporal.TemporalUnit;

public class Java8DateDemo {

	public static void main(String[] args) {
		Instant instant=Instant.now();
		System.out.println(Instant.now());
		
//		System.out.println(Instant.MIN);
//		System.out.println(Instant.MAX);
//		
//		System.out.println(instant.MIN);
//		System.out.println(instant.MAX);
		
		//Duration.between(Temporal, endExclusive)
		
		LocalDate date=LocalDate.now();
		System.out.println(date);
		
		LocalTime time=LocalTime.now();
		
		System.out.println(time);
		
		LocalDate date2=LocalDate.of(2001, 1, 23);
		Period period=Period.between(date,date2);
		System.out.println(period.getMonths());
		System.out.println(period.getYears());
		System.out.println(period.isNegative());
		
		
		Period period2=date2.until(LocalDate.now());
		System.out.println(period2.getDays());
		//period2.until(LocalDate.now(), ChronoField.YEAR);
		
		//period2.
	
		
		
	}

}
