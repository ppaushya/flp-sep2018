package org.cap.demo;

//import static org.demo.OuterClass.InnerClass.*;
import static org.demo.OuterClass.*;
public class Test {

	public static void main(String[] args) {
		
		show();
		//InnerClass.print();
		InnerClass.show();
		InnerClass obj=new InnerClass();
		obj.print();
	}

}
