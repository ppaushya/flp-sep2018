package org.cap.demo;

import java.text.DateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalField;
import java.time.temporal.TemporalUnit;
import java.util.Date;
import java.util.Locale;

public class Demo1 {

	public static void main(String[] args) {
		
		
		Date date=new Date();
		System.out.println(date);
		
		LocalDate localDate= date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		System.out.println(localDate);

		
		
	//	int timeValue=localDate.getLong(localDate.get(1));
		Date d=new Date(localDate.toEpochDay());
		System.out.println(d);
		
		
		
		
		
		
		
		
		
		
		
		
		/*//instant
		Instant instant=Instant.now();
		System.out.println(instant);
		
		//INstant to Date 
		Date newDate=Date.from(instant);
		System.out.println(newDate);
		
		
		//Date into Instant
		Instant newIns= newDate.toInstant();
		System.out.println(newIns);*/
		
		//dd-MMM-yyyy
		
		
	/*	DateFormat format=DateFormat.getDateInstance(3,Locale.getDefault());
		//DateFormat format=DateFormat.
		
		
		System.out.println(format.format(new Date()));*/

	}

}
