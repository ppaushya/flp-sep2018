package org.cap.demo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class ZonedDemo {

	public static void main(String[] args) {
		ZonedDateTime meeting=
				ZonedDateTime.of(
						LocalDate.of(2018, 11, 23),
						LocalTime.of(13, 30),
						ZoneId.of("Europe/Monaco")
						);
		
		System.out.println(meeting.toInstant());
		
		System.out.println(DateTimeFormatter.ISO_DATE_TIME.format(meeting));

	}

}
