package org.cap.demo;

import java.text.DateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class FormatChange {

	public static void main(String[] args) {
		Date date=new Date();
		
	}

}
