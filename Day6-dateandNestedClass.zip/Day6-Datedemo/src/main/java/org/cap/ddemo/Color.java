package org.cap.ddemo;

public enum Color {
	
	/*public enum Type{
		
	}*/

}
