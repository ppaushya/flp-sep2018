package org.cap.ddemo;

public interface InnerInterface {
	
	void draw();
	
	public interface Inner1Interface {
		void fillColor();
	}

}
