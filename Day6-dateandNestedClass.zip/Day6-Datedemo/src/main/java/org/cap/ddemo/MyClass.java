package org.cap.ddemo;

public class MyClass implements InnerInterface, InnerInterface.Inner1Interface{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

}
