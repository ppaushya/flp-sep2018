package org.cap.ddemo;

public class TestClass {

	public static void main(String[] args) {
		
		//=new MyClass();
		
		InnerInterface innerInterface =new InnerInterface() {

			@Override
			public void draw() {
				// TODO Auto-generated method stub
				
			}
			
		};
		
		
		innerInterface.draw();
		
		InnerInterface.Inner1Interface innerInter=new MyClass();
		innerInter.fillColor();
		
		InnerInterface.Inner1Interface obj=new InnerInterface.Inner1Interface() {

			@Override
			public void fillColor() {
				// TODO Auto-generated method stub
				
			}
			
		};

	}

}
