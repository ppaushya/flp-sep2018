package org.cap.demo1;

public class MainClass {
	
	public static void main(String[] args) {
		OuterClass outerClass=new OuterClass();
		outerClass.details();
		
		/*OuterClass.InnerClass obj
			=outerClass.new InnerClass();*/
		//OuterClass$1InnerClass obj=new OuterClass$1InnerClass();
		
		
		
		
	}

}
