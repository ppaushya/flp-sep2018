package org.demo.cap;

public class ChildClass extends AbstractClass{

	@Override
	void print() {
		System.out.println("Child class print method");
	}
	
	/*@Override
	static int add(int num1,int num2) {
		
		return 0;
	}*/

}
