package org.demo.cap;

public class TestClass {

	public static void main(String[] args) {
		
		//TestClass$2
				AbstractClass obj1=new AbstractClass() {
					
					@Override
					void print() {
						System.out.println("My Class Object");
					}
				};
		
		//TestClass$1
		//Annonymous Class
		AbstractClass obj=new AbstractClass() {
			
			@Override
			void print() {
				System.out.println("Annonymous Class Object");
			}
			
		/*	@Override
			 public void non_AbstractMethod() {
				System.out.println("Annonymous Class non_AbstractMethod");
			 }*/
		};
		
		
		
		MyInterface interface1=new MyInterface() {
			
			@Override
			public int add(int num1,int num2) {
				System.out.println("Add");
				return num1;
			}
			
			@Override
			public void fillColor() {
				System.out.println("Fill Color");
				
			}
		};
		
		
		obj.print();
		obj.non_AbstractMethod();
		
		obj1.print();
		interface1.fillColor();
		
		int ans=interface1.add(23, 45);
		System.out.println("Answer:" + ans);
		}

}
