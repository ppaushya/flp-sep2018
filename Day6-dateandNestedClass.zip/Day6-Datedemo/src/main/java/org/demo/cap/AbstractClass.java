package org.demo.cap;

public abstract class AbstractClass {
	
	 abstract void print();
	 
	 public void non_AbstractMethod() {
		 System.out.println("Hey! i am non_AbstractMethod");
	 }
	 
	 static int add(int num1,int num2) {
			
			return 0;
		}

}
