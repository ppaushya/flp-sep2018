package org.demo.cap;

public interface MyInterface {
	
	void fillColor();
	
	default public int add(int num1,int num2) {
		return num1+num2;
	}

}
