package org.demo;

public class OuterClass {
	
	int count=100;
	
	static float pi=3.14f;
	
	public static class InnerClass{
		int num=100;
		public void print() {
			System.out.println("Num:" + num);
			//System.out.println("Count:" + count);
			System.out.println("PI:" + pi);
			show();
			
		}
		
		public static void show() {
			System.out.println("Show Method - Inner Class");
		}
		
	}
	
	

	
	public static void show() {
		System.out.println("Show Method - Outer Class");
	}

}
