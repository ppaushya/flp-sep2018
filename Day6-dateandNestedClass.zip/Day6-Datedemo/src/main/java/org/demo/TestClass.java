package org.demo;

public class TestClass {

	public static void main(String[] args) {
		
		OuterClass.InnerClass.show();
		
		OuterClass.InnerClass obj=new OuterClass.InnerClass();
		obj.print();

	}

}
