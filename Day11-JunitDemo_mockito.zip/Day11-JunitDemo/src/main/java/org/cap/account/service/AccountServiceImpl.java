package org.cap.account.service;

import org.cap.account.dao.AccountDaoImpl;
import org.cap.account.dao.IAccountDao;
import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Account;
import org.cap.account.model.Customer;
import org.cap.account.util.AccountUtility;

public class AccountServiceImpl implements IAccountService {
	
	private IAccountDao accountDao=new AccountDaoImpl();
	
	public  AccountServiceImpl(IAccountDao accountDao) {
		this.accountDao=accountDao;
	}

	@Override
	public Account createAccount(Customer customer, double amount) throws InvalidAmountException {
		if(customer==null)
			throw new IllegalArgumentException("Invalid Customer!");
		if(amount<1000)
			throw new InvalidAmountException("Sorry! Invalid opening Balance!");
		Account account=new Account();
		account.setAccountType("savings");
		account.setBalance(amount);
		account.setAccountNo(AccountUtility.generateAccountNo());
		
		customer.setAccount(account);
		
		if(accountDao.addAccount(customer))
					return account;
		else
			return null;
	}

	@Override
	public Account deposit(Account account, double amount) {
		
		Account account2=accountDao.findAccount(account.getAccountNo());
		if(account2!=null)
		{
			account2.setBalance(account2.getBalance()+amount);
			return account2;
		}
		
		return null;
	}

	@Override
	public Account withdraw(Account account, double amount) {
		Account account2=accountDao.findAccount(account.getAccountNo());
		if(account2!=null)
		{
			if(account2.getBalance()>amount) {
				account2.setBalance(account2.getBalance()-amount);
				return account2;
			}
		}
		return null;
	}

}
