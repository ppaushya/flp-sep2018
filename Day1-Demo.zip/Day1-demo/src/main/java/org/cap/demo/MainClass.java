package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		SimpleInterest interest=new SimpleInterest();
		interest.getData();
		double simpleinter=interest.calculateInterest();
		
		System.out.println("Calculated Interest is:" + simpleinter);

	}

}
