package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {
	
	double principle;
	float years;
	float rateOfInterest;

	
	
	public void getData() {
		/*principle=4000;
		years=3.3f;
		rateOfInterest=0.0665f;*/
		
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Principle:" );
		principle=scanner.nextDouble();
		
		System.out.println("Enter Years:" );
		years=scanner.nextFloat();
		
		System.out.println("Enter Rate OF Interest:" );
		rateOfInterest=scanner.nextFloat();
		
		scanner.close();
		
		
	}
	
	public double calculateInterest() {
		return principle*years*rateOfInterest;
	}

	

}
