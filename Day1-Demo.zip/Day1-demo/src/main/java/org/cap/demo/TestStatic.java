package org.cap.demo;

public class TestStatic {
	
	String name;
	static int count;
	final float pi=3.14f;
	
	
	public static void show() {
	//	System.out.println("Name:" + name);
		System.out.println("Count:" + count);
	}

	public static void main(String[] args) {
		
		TestStatic obj=new TestStatic();
		obj.name="Tom";
		//TestStatic.count=10;
		obj.count=10;
		//obj.show();
		
		System.out.println("Pi:" + obj.pi);
		
		//obj.pi=800.00f;
		
		System.out.println("Name:" + obj.name);
		System.out.println("Count:" + obj.count);
		
		TestStatic obj1=new TestStatic();
		obj1.name="Jerry";
		obj1.count=900;
		//obj1.show();

		System.out.println("Name:" + obj1.name);
		System.out.println("Count:" + obj1.count);
		
	}

}
