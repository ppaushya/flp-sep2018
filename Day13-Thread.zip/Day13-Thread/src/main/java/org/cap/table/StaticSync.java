package org.cap.table;

public class StaticSync {
	
	static String empName="Tom";
	static int count;
	
	public  static void staticMethod() {
		count++;
		synchronized(StaticSync.class) {
		for(int i=0;i<=10;i++)
			System.out.println(Thread.currentThread().getName() + "-->" +i);
		}
		System.out.println("Count:" + count);
	}
	
	public void show() {
		for(int i=0;i<=10;i++)
			System.out.println(Thread.currentThread().getName() + "-->" +empName);
		System.out.println("Count:" + count);
	}

}
